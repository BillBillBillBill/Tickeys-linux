安装：sudo sh install.sh
卸载：sudo sh uninstall.sh
运行：sudo tickeys