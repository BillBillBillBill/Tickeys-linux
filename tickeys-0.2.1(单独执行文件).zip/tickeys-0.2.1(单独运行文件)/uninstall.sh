#!/bin/bash
rm /usr/bin/tickeys
rm /usr/share/icons/Tickeys/tickeys.png
rm /usr/share/applications/Tickeys.desktop
rm /etc/xdg/autostart/Tickeys.desktop
rm ~/.config/autostart/Tickeys.desktop
rm ~/.config/openbox/autostart/Tickeys.desktop
echo Uninstall tickeys success